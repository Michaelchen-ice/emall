package com.emall_3_afternoon.entity;

public class Goods_Photo_Info {
}
