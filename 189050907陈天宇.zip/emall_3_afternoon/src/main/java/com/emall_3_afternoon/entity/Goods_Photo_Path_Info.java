package com.emall_3_afternoon.entity;

public class Goods_Photo_Path_Info {
    private int path_id;
    private int goods_id;
    private String path_name;

    public int getPath_id() {
        return path_id;
    }

    public void setPath_id(int path_id) {
        this.path_id = path_id;
    }

    public int getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(int goods_id) {
        this.goods_id = goods_id;
    }

    public String getPath_name() {
        return path_name;
    }

    public void setPath_name(String path_name) {
        this.path_name = path_name;
    }

    @Override
    public String toString() {
        return "Goods_Photo_Path_Info{" +
                "path_id=" + path_id +
                ", goods_id=" + goods_id +
                ", path_name='" + path_name + '\'' +
                '}';
    }
}
