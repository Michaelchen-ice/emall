package com.emall_3_afternoon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Emall3AfternoonApplicationTests {

    @Test
    void contextLoads() {
    }

}
